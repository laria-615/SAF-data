import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler, PowerTransformer
import warnings
import time
from sklearn.metrics import make_scorer
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from copy import deepcopy

warnings.filterwarnings("ignore")


# 1. 自定义评估指标和早停SVR类
def mean_relative_error(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / (y_true + 1e-10)))


neg_mre_scorer = make_scorer(mean_relative_error, greater_is_better=False)


class EarlyStoppingSVR(BaseEstimator, RegressorMixin):
    def __init__(self, kernel='rbf', degree=3, C=1.0, epsilon=0.1, gamma='scale',
                 coef0=0.0, tol=1e-4, max_iter=500, patience=10,
                 validation_fraction=0.1, random_state=None):
        self.kernel = kernel
        self.degree = degree
        self.C = C
        self.epsilon = epsilon
        self.gamma = gamma
        self.coef0 = coef0
        self.tol = tol
        self.max_iter = max_iter
        self.patience = patience
        self.validation_fraction = validation_fraction
        self.random_state = random_state

    def _split_val_set(self, X, y):
        if self.validation_fraction > 0:
            X_train, X_val, y_train, y_val = train_test_split(
                X, y, test_size=self.validation_fraction,
                random_state=self.random_state)
            return X_train, y_train, X_val, y_val
        return X, y, None, None

    def fit(self, X, y):
        X, y = check_X_y(X, y)
        X_train, y_train, X_val, y_val = self._split_val_set(X, y)

        self.base_svr_ = svm.SVR(
            kernel=self.kernel,
            degree=self.degree,  # 添加degree参数
            C=self.C,
            epsilon=self.epsilon,
            gamma=self.gamma,
            coef0=self.coef0,
            tol=self.tol,
            max_iter=1  # 每次只迭代一次
        )

        if X_val is None:
            self.base_svr_.max_iter = self.max_iter
            self.base_svr_.fit(X_train, y_train)
            return self

        best_loss = np.inf
        no_improvement = 0
        best_model = None

        for iter in range(self.max_iter):
            self.base_svr_.fit(X_train, y_train)
            y_pred = self.base_svr_.predict(X_val)
            current_loss = mean_relative_error(y_val, y_pred)

            if current_loss < best_loss - self.tol:
                best_loss = current_loss
                no_improvement = 0
                best_model = deepcopy(self.base_svr_)
            else:
                no_improvement += 1

            if no_improvement >= self.patience:
                print(f"Early stopping at iteration {iter + 1}, best val MRE: {best_loss:.4f}")
                if best_model:
                    self.base_svr_ = best_model
                break

        return self

    def predict(self, X):
        check_is_fitted(self, 'base_svr_')
        X = check_array(X)
        return self.base_svr_.predict(X)


# 2. 数据准备
print("\n" + "=" * 50 + "\n数据准备阶段\n" + "=" * 50)
start_time = time.time()

df = pd.read_csv('pipe_data.csv').dropna()
X = df[['inlet_velocity', 'degree']]
y = df['main_mass_flow']  # 单输出

# 增强的预处理
scaler_X = PowerTransformer()
scaler_y = PowerTransformer()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.values.reshape(-1, 1)).ravel()

# 数据分割
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=42)

print(f"\n数据维度: 训练集{X_train.shape}, 验证集{X_val.shape}, 测试集{X_test.shape}")
print(f"数据准备耗时: {time.time() - start_time:.2f}秒")

# 3. 模型配置
models = {
    'linear': {
        'model': EarlyStoppingSVR(kernel='linear', random_state=42),
        'params': {
            'C': [0.001, 0.01, 0.1, 1, 10],
            'epsilon': [0.01, 0.1, 0.5]
        }
    },
    'rbf': {
        'model': EarlyStoppingSVR(kernel='rbf', random_state=42),
        'params': {
            'C': [0.001, 0.01, 0.1, 1, 10],
            'gamma': ['scale', 'auto', 0.01, 0.1],
            'epsilon': [0.01, 0.1, 0.5]
        }
    },
    'poly': {
        'model': EarlyStoppingSVR(kernel='poly', random_state=42),
        'params': {
            'C': [0.001, 0.01, 0.1, 1, 10],
            'degree': [2, 3],  # 现在可以正确传递degree参数
            'gamma': ['scale', 'auto', 0.01, 0.1],
            'coef0': [0.0, 1.0],
            'epsilon': [0.01, 0.1, 0.5]
        }
    }
}

# 4. 模型训练与评估
print("\n" + "=" * 50 + "\n模型训练阶段\n" + "=" * 50)
results = []

for mod_name, mod_info in models.items():
    print(f"\n{'=' * 20} {mod_name} {'=' * 20}")
    model_time = time.time()

    grid = GridSearchCV(
        mod_info['model'],
        mod_info['params'],
        cv=5,
        scoring=neg_mre_scorer,
        verbose=2,
        n_jobs=1,
        return_train_score=True
    )

    print(f"开始训练{mod_name}模型...")
    grid.fit(X_train, y_train)

    # 评估最佳模型
    best_model = grid.best_estimator_

    # 验证集评估
    y_pred_val = best_model.predict(X_val)
    y_pred_val_orig = scaler_y.inverse_transform(y_pred_val.reshape(-1, 1)).ravel()
    y_val_orig = scaler_y.inverse_transform(y_val.reshape(-1, 1)).ravel()
    mre_val = mean_relative_error(y_val_orig, y_pred_val_orig)
    r2_val = r2_score(y_val_orig, y_pred_val_orig)

    # 测试集评估
    y_pred_test = best_model.predict(X_test)
    y_pred_test_orig = scaler_y.inverse_transform(y_pred_test.reshape(-1, 1)).ravel()
    y_test_orig = scaler_y.inverse_transform(y_test.reshape(-1, 1)).ravel()
    mre_test = mean_relative_error(y_test_orig, y_pred_test_orig)
    r2_test = r2_score(y_test_orig, y_pred_test_orig)

    # 保存结果
    results.append({
        'model': mod_name,
        'best_params': grid.best_params_,
        'val_mre': mre_val,
        'val_r2': r2_val,
        'test_mre': mre_test,
        'test_r2': r2_test,
        'train_time': time.time() - model_time
    })

    # 保存预测结果
    pd.DataFrame({
        'true': y_test_orig,
        'pred': y_pred_test_orig
    }).to_csv(f'predictions_{mod_name}.csv', index=False)

# 5. 结果展示
print("\n" + "=" * 50 + "\n最终结果\n" + "=" * 50)
results_df = pd.DataFrame(results)
print(results_df[['model', 'test_mre', 'test_r2', 'train_time']].to_string(index=False))

# 找出最佳模型
best_model_idx = results_df['test_mre'].idxmin()
print(f"\n最佳模型: {results_df.loc[best_model_idx, 'model']}")
print(f"测试集MRE: {results_df.loc[best_model_idx, 'test_mre']:.4f}")
print(f"总运行时间: {time.time() - start_time:.2f}秒")