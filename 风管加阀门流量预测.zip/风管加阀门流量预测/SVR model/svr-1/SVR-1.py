import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import time

# 1. 数据准备
print("="*50)
print("数据准备阶段")
print("="*50)
df = pd.read_csv('pipe_data.csv').dropna()
X = df[['inlet_velocity', 'degree']]
y = df['branch_mass_flow']  # 单输出

# 数据标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分数据集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 2. RBF核参数优化
print("\n" + "="*50)
print("RBF SVR参数优化")
print("="*50)

# 定义参数网格
param_grid = {
    'C': np.logspace(-2, 2, 5),       # [0.01, 0.1, 1, 10, 100]
    'gamma': np.logspace(-3, 1, 5),    # [0.001, 0.01, 0.1, 1, 10]
    'epsilon': [0.01, 0.1, 0.5]       # 不敏感区域
}

# 创建模型
svr = svm.SVR(kernel='rbf')

# 网格搜索
grid_search = GridSearchCV(
    estimator=svr,
    param_grid=param_grid,
    scoring='neg_mean_absolute_error',
    cv=5,
    n_jobs=-1,
    verbose=1
)

start_time = time.time()
grid_search.fit(X_train, y_train)
print(f"\n参数搜索耗时: {time.time()-start_time:.2f}秒")

# 3. 结果分析
best_params = grid_search.best_params_
print("\n最佳参数组合:", best_params)
print("最佳交叉验证MAE:", -grid_search.best_score_)

# 4. 使用最佳模型评估
best_svr = grid_search.best_estimator_

# 训练集表现
y_train_pred = best_svr.predict(X_train)
train_mae = mean_absolute_error(y_train, y_train_pred)
train_r2 = r2_score(y_train, y_train_pred)

# 测试集表现
y_test_pred = best_svr.predict(X_test)
test_mae = mean_absolute_error(y_test, y_test_pred)
test_r2 = r2_score(y_test, y_test_pred)

print("\n" + "="*50)
print("模型评估结果")
print("="*50)
print(f"训练集 MAE: {train_mae:.4f}, R²: {train_r2:.4f}")
print(f"测试集 MAE: {test_mae:.4f}, R²: {test_r2:.4f}")

# 5. 保存预测结果
results_df = pd.DataFrame({
    '实际值': y_test,
    '预测值': y_test_pred,
    '残差': y_test - y_test_pred
})
results_df.to_csv('svr_predictions.csv', index=False)

print("\n优化完成，结果已保存到svr_predictions.csv！")