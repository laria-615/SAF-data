import numpy as np
import pandas as pd
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import warnings

warnings.filterwarnings("ignore")  # 忽略警告

# 1. 数据准备
# 从CSV文件中加载数据
df = pd.read_csv('pipe_data.csv')

# 检查数据是否有缺失值
print("数据缺失值统计：")
print(df.isnull().sum())

# 删除包含缺失值的行
df = df.dropna()

# 输入特征
X = df[['inlet_velocity', 'degree']]

# 输出标签 - 确保只有2列（main_mass_flow和branch_mass_flow）
y = df[['main_mass_flow', 'branch_mass_flow']]

# 检查 X 和 y 的样本数量
print(f"X 的样本数量: {len(X)}")
print(f"y 的样本数量: {len(y)}")
print(f"y 的形状: {y.shape}")  # 应该是(n_samples, 2)

# 定义模型和激活函数的组合
mods = ['lbfgs']
moods = ['identity', 'logistic']

# 使用 train_test_split 划分数据集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=42)

# 检查划分后的样本数量
print(f"训练集样本数量: {len(X_train)}")
print(f"验证集样本数量: {len(X_val)}")
print(f"测试集样本数量: {len(X_test)}")

# 遍历模型和激活函数
# ...（前面的数据准备和模型训练代码保持不变）
# ...（前面的数据准备和模型训练代码保持不变）

for mod in mods:
    for mood in moods:
        # 模型训练与预测
        clf = MLPRegressor(solver=mod, activation=mood, hidden_layer_sizes=(1, 1, 3), random_state=42)
        clf.fit(X_train, y_train.values if hasattr(y_train, 'values') else y_train)

        # 转换为数组格式
        y_val_array = y_val.values if hasattr(y_val, 'values') else y_val
        y_test_array = y_test.values if hasattr(y_test, 'values') else y_test

        # 在验证集上评估
        y_predict_val = clf.predict(X_val)
        mse_val = mean_squared_error(y_val_array, y_predict_val)
        r2_val = r2_score(y_val_array, y_predict_val)

        # 在测试集上评估
        y_predict_test = clf.predict(X_test)
        mse_test = mean_squared_error(y_test_array, y_predict_test)
        r2_test = r2_score(y_test_array, y_predict_test)

        # 创建结果DataFrame
        results_df = pd.DataFrame({
            'inlet_velocity': X_test.iloc[:, 0],
            'degree': X_test.iloc[:, 1],
            'main_mass_flow_true': y_test_array[:, 0],
            'branch_mass_flow_true': y_test_array[:, 1],
            'main_mass_flow_pred': y_predict_test[:, 0],
            'branch_mass_flow_pred': y_predict_test[:, 1]
        })

        # 保存到CSV文件
        output_filename = f'test_set_predictions_{mod}_{mood}.csv'
        results_df.to_csv(output_filename, index=False)

        # 输出评估结果
        print(f'Model: {mod}, Activation: {mood}')
        print(f'验证集 - MSE: {mse_val:.4f}, R²: {r2_val:.4f}')
        print(f'测试集 - MSE: {mse_test:.4f}, R²: {r2_test:.4f}')
        print('-' * 50)