import numpy as np
import pandas as pd
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
import warnings
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")  # 忽略警告

# 1. 数据准备
# 从CSV文件中加载数据
df = pd.read_csv('pipe_data.csv')

# 检查数据是否有缺失值
print("数据缺失值统计：")
print(df.isnull().sum())

# 删除包含缺失值的行
df = df.dropna()

# 输入特征
X = df[['inlet_velocity', 'degree']].values  # 转换为numpy数组
# 输出标签
y = df[['main_mass_flow', 'branch_mass_flow']].values

# 数据标准化
scaler_X = StandardScaler()
scaler_y = StandardScaler()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y)

# 检查数据形状
print(f"\n数据形状检查:")
print(f"X 形状: {X_scaled.shape}, y 形状: {y_scaled.shape}")

# 划分数据集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42)
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=42)

print("\n数据集划分结果:")
print(f"训练集: {X_train.shape[0]} 样本")
print(f"验证集: {X_val.shape[0]} 样本")
print(f"测试集: {X_test.shape[0]} 样本")

# 2. 参数网格搜索设置
param_grid = {
    'hidden_layer_sizes': [(10,), (30,15), (50,30,10)],
    'activation': ['relu', 'tanh'],
    'alpha': [0.0001, 0.001],  # L2正则化参数
    'learning_rate_init': [0.001, 0.01],
    'max_iter': [500, 1000]
}

# 3. 网格搜索执行
print("\n开始网格搜索...")
mlp = MLPRegressor(solver='adam', early_stopping=True, random_state=42)
grid_search = GridSearchCV(mlp, param_grid, cv=5, scoring='neg_mean_squared_error',
                          n_jobs=-1, verbose=1)
grid_search.fit(X_train, y_train)

# 输出最佳参数
print("\n最佳参数组合:")
best_params = grid_search.best_params_
for param, value in best_params.items():
    print(f"{param}: {value}")

# 4. 使用最佳模型评估
best_model = grid_search.best_estimator_

# 在验证集上评估
y_val_pred = best_model.predict(X_val)
val_mse = mean_squared_error(y_val, y_val_pred)
val_r2 = r2_score(y_val, y_val_pred)

# 在测试集上评估
y_test_pred = best_model.predict(X_test)
test_mse = mean_squared_error(y_test, y_test_pred)
test_r2 = r2_score(y_test, y_test_pred)

print("\n模型评估结果:")
print(f"验证集 - MSE: {val_mse:.4f}, R²: {val_r2:.4f}")
print(f"测试集 - MSE: {test_mse:.4f}, R²: {test_r2:.4f}")

# 5. 结果保存与可视化
# 反标准化还原原始量纲
X_test_orig = scaler_X.inverse_transform(X_test)
y_test_orig = scaler_y.inverse_transform(y_test)
y_test_pred_orig = scaler_y.inverse_transform(y_test_pred)

# 创建结果DataFrame
results_df = pd.DataFrame({
    'inlet_velocity': X_test_orig[:, 0],
    'degree': X_test_orig[:, 1],
    'main_mass_flow_true': y_test_orig[:, 0],
    'branch_mass_flow_true': y_test_orig[:, 1],
    'main_mass_flow_pred': y_test_pred_orig[:, 0],
    'branch_mass_flow_pred': y_test_pred_orig[:, 1]
})

# 保存结果
output_filename = 'best_model_predictions.csv'
results_df.to_csv(output_filename, index=False)
print(f"\n预测结果已保存到: {output_filename}")

# 可视化预测效果
plt.figure(figsize=(12, 5))
for i, col in enumerate(['main_mass_flow', 'branch_mass_flow']):
    plt.subplot(1, 2, i+1)
    plt.scatter(y_test_orig[:, i], y_test_pred_orig[:, i], alpha=0.5)
    plt.plot([y_test_orig[:, i].min(), y_test_orig[:, i].max()],
             [y_test_orig[:, i].min(), y_test_orig[:, i].max()], 'r--')
    plt.xlabel(f'True {col}')
    plt.ylabel(f'Predicted {col}')
    plt.title(f'{col} Prediction')
plt.tight_layout()
plt.savefig('prediction_plot.png')
print("可视化图表已保存为: prediction_plot.png")