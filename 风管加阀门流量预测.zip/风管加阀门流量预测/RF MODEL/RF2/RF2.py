# 导入必要的库
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# 1. 数据准备
# 从CSV文件中加载数据
df = pd.read_csv('pipe_data.csv')

# 输入特征 - 根据您说的4个特征，这里需要调整
# 假设特征为：'inlet_velocity', 'degree', 'feature3', 'feature4'
X = df[['inlet_velocity', 'degree']]  # 请替换为实际的4个特征名

# 输出标签
y = df[['main_mass_flow', 'branch_mass_flow']]

# 2. 数据分割
# 将数据集分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 从训练集中划分出验证集
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=42)

# 3. 特征工程（可选）
# 可以添加多项式特征或交互特征
# from sklearn.preprocessing import PolynomialFeatures
# poly = PolynomialFeatures(degree=2, interaction_only=True)
# X_train_poly = poly.fit_transform(X_train)
# X_val_poly = poly.transform(X_val)
# X_test_poly = poly.transform(X_test)

# 4. 模型训练与参数调优
# 设置参数网格
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2']
}

# 初始化随机森林回归模型
rf_model = RandomForestRegressor(random_state=42, n_jobs=-1)

# 使用网格搜索进行参数调优
grid_search = GridSearchCV(estimator=rf_model, param_grid=param_grid,
                          cv=5, n_jobs=-1, verbose=2,
                          scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)

# 获取最佳模型
best_rf_model = grid_search.best_estimator_

# 打印最佳参数
print("Best Parameters:", grid_search.best_params_)

# 5. 模型预测
# 在测试集上进行预测
y_pred_test = best_rf_model.predict(X_test)

# 在验证集上进行预测
y_pred_val = best_rf_model.predict(X_val)

# 6. 模型评估
# 计算测试集的均方误差（MSE）和决定系数（R²）
mse_test = mean_squared_error(y_test, y_pred_test)
r2_test = r2_score(y_test, y_pred_test)

# 计算验证集的均方误差（MSE）和决定系数（R²）
mse_val = mean_squared_error(y_val, y_pred_val)
r2_val = r2_score(y_val, y_pred_val)

print(f'Test Set - Mean Squared Error (MSE): {mse_test}')
print(f'Test Set - R-squared (R²): {r2_test}')
print(f'Validation Set - Mean Squared Error (MSE): {mse_val}')
print(f'Validation Set - R-squared (R²): {r2_val}')

# 7. 特征重要性分析
importances = best_rf_model.feature_importances_
feature_names = X.columns
feature_importance_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)
print("\nFeature Importance:")
print(feature_importance_df)

# 8. 保存模型和结果
# 保存最佳模型
joblib.dump(best_rf_model, 'best_random_forest_model.pkl')

# 创建测试集的 DataFrame
test_results_df = pd.concat([
    X_test.reset_index(drop=True),
    y_test.reset_index(drop=True),
    pd.DataFrame(y_pred_test, columns=['pred_main_mass_flow', 'pred_branch_mass_flow'])
], axis=1)

# 保存测试集的预测结果到CSV文件
test_results_df.to_csv('improved_test_set_predictions.csv', index=False)
print("\n测试集的每组数据（输入特征、真实标签和预测值）已保存到 improved_test_set_predictions.csv")

# 创建验证集的 DataFrame
val_results_df = pd.concat([
    X_val.reset_index(drop=True),
    y_val.reset_index(drop=True),
    pd.DataFrame(y_pred_val, columns=['pred_main_mass_flow', 'pred_branch_mass_flow'])
], axis=1)

# 保存验证集的预测结果到CSV文件
val_results_df.to_csv('improved_validation_set_predictions.csv', index=False)
print("验证集的每组数据（输入特征、真实标签和预测值）已保存到 improved_validation_set_predictions.csv")