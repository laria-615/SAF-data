# 导入必要的库
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
import joblib


# 定义平均相对误差(MRE)计算函数
def mean_relative_error(y_true, y_pred):
    """
    计算平均相对误差(Mean Relative Error)

    参数:
    y_true -- 真实值数组
    y_pred -- 预测值数组

    返回:
    MRE值
    """
    # 添加小常数防止除以0，同时保持相对误差的稳定性
    epsilon = 1e-10
    relative_errors = np.abs((y_true - y_pred) / (np.abs(y_true) + epsilon))
    return np.mean(relative_errors)


# 1. 数据准备
# 从CSV文件中加载数据
df = pd.read_csv('pipe_data.csv')

# 输入特征
X = df[['inlet_velocity', 'degree']]

# 输出标签
y = df[['main_mass_flow', 'branch_mass_flow']]

# 2. 数据分割
# 将数据集分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 从训练集中划分出验证集
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.25, random_state=42)

# 3. 模型训练
# 初始化随机森林回归模型
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)

# 训练模型
rf_model.fit(X_train, y_train)

# 4. 模型预测
# 在测试集上进行预测
y_pred_test = rf_model.predict(X_test)

# 在验证集上进行预测
y_pred_val = rf_model.predict(X_val)

# 5. 模型评估 - 使用MRE和R²
# 计算测试集的MRE和R²
mre_test_main = mean_relative_error(y_test['main_mass_flow'], y_pred_test[:, 0])
mre_test_branch = mean_relative_error(y_test['branch_mass_flow'], y_pred_test[:, 1])
r2_test = r2_score(y_test, y_pred_test)

# 计算验证集的MRE和R²
mre_val_main = mean_relative_error(y_val['main_mass_flow'], y_pred_val[:, 0])
mre_val_branch = mean_relative_error(y_val['branch_mass_flow'], y_pred_val[:, 1])
r2_val = r2_score(y_val, y_pred_val)

print('测试集评估结果:')
print(f'主流量MRE: {mre_test_main:.4%}')  # 以百分比形式显示
print(f'支管流量MRE: {mre_test_branch:.4%}')
print(f'整体R²: {r2_test:.6f}')

print('\n验证集评估结果:')
print(f'主流量MRE: {mre_val_main:.4%}')
print(f'支管流量MRE: {mre_val_branch:.4%}')
print(f'整体R²: {r2_val:.6f}')

# 6. 保存预测结果
# 创建测试集的DataFrame
test_results_df = pd.concat([
    X_test.reset_index(drop=True),
    y_test.reset_index(drop=True),
    pd.DataFrame(y_pred_test, columns=['pred_main_mass_flow', 'pred_branch_mass_flow'])
], axis=1)

# 计算并添加相对误差列
test_results_df['main_flow_relative_error'] = np.abs(
    (test_results_df['main_mass_flow'] - test_results_df['pred_main_mass_flow']) /
    (test_results_df['main_mass_flow'] + 1e-10))
test_results_df['branch_flow_relative_error'] = np.abs(
    (test_results_df['branch_mass_flow'] - test_results_df['pred_branch_mass_flow']) /
    (test_results_df['branch_mass_flow'] + 1e-10))

# 保存测试集的预测结果
test_results_df.to_csv('test_set_predictions_with_mre.csv', index=False)
print("\n测试集预测结果(含相对误差)已保存到 test_set_predictions_with_mre.csv")

# 创建验证集的DataFrame
val_results_df = pd.concat([
    X_val.reset_index(drop=True),
    y_val.reset_index(drop=True),
    pd.DataFrame(y_pred_val, columns=['pred_main_mass_flow', 'pred_branch_mass_flow'])
], axis=1)

# 计算并添加相对误差列
val_results_df['main_flow_relative_error'] = np.abs(
    (val_results_df['main_mass_flow'] - val_results_df['pred_main_mass_flow']) /
    (val_results_df['main_mass_flow'] + 1e-10))
val_results_df['branch_flow_relative_error'] = np.abs(
    (val_results_df['branch_mass_flow'] - val_results_df['pred_branch_mass_flow']) /
    (val_results_df['branch_mass_flow'] + 1e-10))

# 保存验证集的预测结果
val_results_df.to_csv('validation_set_predictions_with_mre.csv', index=False)
print("验证集预测结果(含相对误差)已保存到 validation_set_predictions_with_mre.csv")