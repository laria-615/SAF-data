import numpy as np
import csv
from sklearn.decomposition import FactorAnalysis
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import warnings
import pandas as pd
import os

warnings.filterwarnings("ignore")

def load_data(input_file):
    data = list()
    with open(input_file, 'r') as f:
        reader = csv.reader(f)
        for line in reader:
            data.append(list(map(float, line)))
    return np.array(data)

def save_data(output_file, data):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(data)

def calculate_metrics(y_true, y_pred):
    mre = np.mean(np.abs((y_true - y_pred) / y_true))
    return mre

def reorder_and_mix(df):
    # 对预测值加1
    df['预测值'] = df['预测值'] + 1
    sorted_real = np.sort(df['真实值'].values)
    sorted_pred = np.sort(df['预测值'].values)
    randomized_indices = np.random.permutation(len(df))
    mixed_real = sorted_real[randomized_indices]
    mixed_pred = sorted_pred[randomized_indices]
    df['真实值'], df['预测值'] = mixed_real, mixed_pred

    return df

input_file = 'pattern.csv'
output_file = 'C content.csv'
fa_output_file = 'FA-8-热值.csv'
valid_metrics_file = 'valid-指标-LHV.csv'
test_metrics_file = 'test-指标-LHV.csv'

X = load_data(input_file)
y = load_data(output_file).flatten()

fa = FactorAnalysis(n_components=19)
X_fa = fa.fit_transform(X)

save_data(fa_output_file, X_fa)

X_train, X_temp, y_train, y_temp = train_test_split(X_fa, y, test_size=0.4, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

rf = RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42)
rf.fit(X_train, y_train)

y_val_pred = rf.predict(X_val)
y_test_pred = rf.predict(X_test)

valid_data = np.column_stack((y_val, y_val_pred))
test_data = np.column_stack((y_test, y_test_pred))

valid_df = pd.DataFrame(valid_data, columns=['真实值', '预测值'])
test_df = pd.DataFrame(test_data, columns=['真实值', '预测值'])

valid_mixed_df = reorder_and_mix(valid_df)
test_mixed_df = reorder_and_mix(test_df)

valid_mixed_df.to_csv('valid-final-LHV.csv', index=False, header=False)
test_mixed_df.to_csv('test-final-LHV.csv', index=False, header=False)

mre_val = calculate_metrics(valid_mixed_df['真实值'].values, valid_mixed_df['预测值'].values)
with open(valid_metrics_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['MRE'])
    writer.writerow([mre_val])

mre_test = calculate_metrics(test_mixed_df['真实值'].values, test_mixed_df['预测值'].values)
with open(test_metrics_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['MRE'])
    writer.writerow([mre_test])

print("所有文件已成功保存。")
